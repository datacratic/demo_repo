def start():
    print "I'm a module"