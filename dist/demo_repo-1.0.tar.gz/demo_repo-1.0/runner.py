import package.module

package.module.start()