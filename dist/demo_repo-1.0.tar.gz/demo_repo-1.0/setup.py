from distutils.core import setup
setup(name='demo_repo',
      version='1.0',
      packages = ['package'],
      py_modules=['runner'],
      )